import { useMemo, useState } from 'react'
import {
  Apple,
  Beef,
  Camera,
  Coffee,
  Droplets,
  Flame,
  ImagePlus,
  Moon,
  Plus,
  RotateCcw,
  Salad,
  Scale,
  Trash2,
  Utensils,
  X,
} from 'lucide-react'

import PageHeader from '../components/ui/PageHeader'
import Card from '../components/ui/Card'
import Badge from '../components/ui/Badge'
import Button from '../components/ui/Button'
import Input from '../components/ui/Input'
import Select from '../components/ui/Select'
import Textarea from '../components/ui/Textarea'
import {
  addMeal,
  addWater,
  getTodayNutrition,
  removeMeal,
  setWater,
  updateNutritionGoals,
} from '../services/nutritionService'

const MEAL_TYPES = [
  { value: 'breakfast', label: 'Café da manhã', icon: Coffee },
  { value: 'lunch', label: 'Almoço', icon: Utensils },
  { value: 'dinner', label: 'Jantar', icon: Moon },
  { value: 'snack', label: 'Lanche', icon: Apple },
  { value: 'pre-workout', label: 'Pré-treino', icon: Beef },
  { value: 'post-workout', label: 'Pós-treino', icon: Salad },
]

import AppPageIntro from '../components/app/AppPageIntro'

function clampPercent(value, goal) {
  const safeGoal = Math.max(1, Number(goal) || 1)
  return Math.max(0, Math.min(100, Math.round(((Number(value) || 0) / safeGoal) * 100)))
}

function getMealTypeLabel(type) {
  return MEAL_TYPES.find((item) => item.value === type)?.label || 'Refeição'
}

async function compressMealPhoto(file) {
  if (!file) return null
  if (!file.type?.startsWith('image/')) {
    throw new Error('Selecione uma imagem válida.')
  }

  if (file.size > 8 * 1024 * 1024) {
    throw new Error('A imagem é muito grande. Use uma foto com até 8 MB.')
  }

  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(String(reader.result || ''))
    reader.onerror = () => reject(new Error('Não foi possível ler a imagem.'))
    reader.readAsDataURL(file)
  })

  const image = await new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => resolve(img)
    img.onerror = () => reject(new Error('Não foi possível carregar a imagem.'))
    img.src = dataUrl
  })

  const maxSize = 900
  const scale = Math.min(1, maxSize / Math.max(image.width || 1, image.height || 1))
  const canvas = document.createElement('canvas')
  canvas.width = Math.max(1, Math.round((image.width || 1) * scale))
  canvas.height = Math.max(1, Math.round((image.height || 1) * scale))
  const ctx = canvas.getContext('2d')
  ctx.drawImage(image, 0, 0, canvas.width, canvas.height)
  const compressed = canvas.toDataURL('image/jpeg', 0.78)

  return {
    dataUrl: compressed,
    mimeType: 'image/jpeg',
    size: Math.round((compressed.length * 3) / 4),
    capturedAt: new Date().toISOString(),
  }
}

function MetricCard({ icon: Icon, title, value, goal, suffix, description }) {
  const percent = clampPercent(value, goal)

  return (
    <Card className="ff-nutrition-metric-card p-4">
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 items-center gap-3">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-[var(--ff-accent-soft)] text-[var(--ff-accent-text)]">
            <Icon size={21} />
          </span>
          <div className="min-w-0">
            <p className="text-xs font-black uppercase tracking-[0.14em] text-[var(--ff-muted)]">{title}</p>
            <p className="mt-1 text-xl font-black text-[var(--ff-text)]">
              {value}<span className="text-sm text-[var(--ff-muted)]">/{goal}{suffix}</span>
            </p>
          </div>
        </div>
        <Badge>{percent}%</Badge>
      </div>
      <div className="mt-4 h-2 overflow-hidden rounded-full bg-[var(--ff-surface-3)]">
        <div className="h-full rounded-full bg-[var(--ff-accent)] transition-all" style={{ width: `${percent}%` }} />
      </div>
      {description && <p className="mt-2 text-xs text-[var(--ff-muted)]">{description}</p>}
    </Card>
  )
}

function MealPhotoPicker({ photo, onChange, error, onError }) {
  async function handleFileChange(event) {
    const file = event.target.files?.[0]
    event.target.value = ''
    if (!file) return

    try {
      onError('')
      const compressed = await compressMealPhoto(file)
      onChange(compressed)
    } catch (err) {
      onError(err?.message || 'Não foi possível adicionar a foto.')
    }
  }

  return (
    <div className="ff-meal-photo-picker">
      <label className="block text-sm font-bold text-[var(--ff-text-soft)]">Foto da comida</label>
      <div className="mt-2 flex flex-col gap-3 sm:flex-row sm:items-center">
        <label className="flex min-h-[112px] flex-1 cursor-pointer items-center justify-center rounded-3xl border border-dashed border-[var(--ff-border)] bg-[var(--ff-surface-2)] p-3 text-center transition hover:border-[var(--ff-accent-border)] hover:bg-[var(--ff-accent-soft)]/10">
          <input type="file" accept="image/*" capture="environment" className="sr-only" onChange={handleFileChange} />
          {photo?.dataUrl ? (
            <img src={photo.dataUrl} alt="Prévia da refeição" className="h-28 w-full rounded-2xl object-cover" />
          ) : (
            <span className="flex flex-col items-center gap-2 text-sm font-bold text-[var(--ff-muted)]">
              <ImagePlus size={28} />
              Adicionar foto
            </span>
          )}
        </label>
        {photo?.dataUrl && (
          <Button type="button" variant="secondary" onClick={() => onChange(null)} className="sm:w-auto">
            <X size={16} /> Remover
          </Button>
        )}
      </div>
      {error && <p className="mt-2 text-xs font-bold text-red-300">{error}</p>}
    </div>
  )
}

function Nutrition() {
  const [nutrition, setNutrition] = useState(() => getTodayNutrition())
  const [meal, setMeal] = useState({
    name: '',
    type: 'lunch',
    calories: '',
    proteinG: '',
    carbsG: '',
    fatG: '',
    notes: '',
    time: new Date().toTimeString().slice(0, 5),
    photo: null,
  })
  const [photoError, setPhotoError] = useState('')
  const [goals, setGoals] = useState(() => ({
    waterGoalMl: getTodayNutrition().waterGoalMl,
    calorieGoal: getTodayNutrition().calorieGoal,
    proteinGoalG: getTodayNutrition().proteinGoalG,
  }))

  const waterPercent = useMemo(() => clampPercent(nutrition.waterMl, nutrition.waterGoalMl), [nutrition.waterGoalMl, nutrition.waterMl])

  function handleAddWater(amount) {
    setNutrition(addWater(amount))
  }

  function handleAddMeal(event) {
    event.preventDefault()
    if (!meal.name.trim() && !meal.calories && !meal.proteinG && !meal.photo) return
    setNutrition(addMeal(meal))
    setMeal({
      name: '',
      type: 'lunch',
      calories: '',
      proteinG: '',
      carbsG: '',
      fatG: '',
      notes: '',
      time: new Date().toTimeString().slice(0, 5),
      photo: null,
    })
    setPhotoError('')
  }

  function handleSaveGoals(event) {
    event.preventDefault()
    setNutrition(updateNutritionGoals(goals))
  }

  return (
    <div className="ff-hevy-page ff-hevy-page-nutrition">

      <AppPageIntro
        eyebrow="Nutrição"
        title="Hoje"
        description="Registre água, refeições e macros em blocos rápidos."
        metrics={[
          { label: 'Refeições', value: nutrition.meals.length },
          { label: 'Kcal', value: nutrition.calories },
          { label: 'Proteína', value: `${nutrition.proteinG}g` },
        ]}
      />

    <div className="ff-nutrition-page space-y-5">
      <PageHeader
        title="Nutrição"
        description="Acompanhe hidratação, refeições e metas simples junto com seus treinos."
        
      />

      <Card className="ff-nutrition-hero overflow-hidden p-4 sm:p-5">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <p className="text-xs font-black uppercase tracking-[0.16em] text-[var(--ff-accent-text)]">Resumo do dia</p>
            <h2 className="mt-1 text-2xl font-black text-[var(--ff-text)]">Energia para evoluir</h2>
            <p className="mt-2 text-sm leading-relaxed text-[var(--ff-muted)]">Registre o essencial sem transformar nutrição em uma planilha.</p>
          </div>
          <div className="grid grid-cols-3 gap-2 text-center sm:min-w-[260px]">
            <div className="rounded-2xl bg-[var(--ff-surface-2)] p-3"><p className="text-lg font-black">{nutrition.meals.length}</p><p className="text-[10px] font-black uppercase text-[var(--ff-muted)]">refeições</p></div>
            <div className="rounded-2xl bg-[var(--ff-surface-2)] p-3"><p className="text-lg font-black">{nutrition.calories}</p><p className="text-[10px] font-black uppercase text-[var(--ff-muted)]">kcal</p></div>
            <div className="rounded-2xl bg-[var(--ff-surface-2)] p-3"><p className="text-lg font-black">{nutrition.proteinG}g</p><p className="text-[10px] font-black uppercase text-[var(--ff-muted)]">proteína</p></div>
          </div>
        </div>
      </Card>

      <section className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <MetricCard icon={Droplets} title="Hidratação" value={nutrition.waterMl} goal={nutrition.waterGoalMl} suffix="ml" description="Meta diária configurável" />
        <MetricCard icon={Flame} title="Calorias" value={nutrition.calories} goal={nutrition.calorieGoal} suffix="kcal" description="Total vindo das refeições" />
        <MetricCard icon={Scale} title="Proteína" value={nutrition.proteinG} goal={nutrition.proteinGoalG} suffix="g" description="Foco em recuperação" />
      </section>

      <section className="grid grid-cols-1 gap-4 xl:grid-cols-[minmax(0,1.15fr)_minmax(340px,.85fr)]">
        <div className="space-y-4">
          <Card className="ff-hydration-card p-4 sm:p-5">
            <div className="flex items-start gap-3">
              <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-cyan-500/10 text-cyan-200">
                <Droplets size={24} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h2 className="text-xl font-black text-[var(--ff-text)]">Hidratação do dia</h2>
                    <p className="mt-1 text-sm text-[var(--ff-muted)]">{waterPercent}% da meta concluída.</p>
                  </div>
                  <Button type="button" variant="ghost" onClick={() => setNutrition(setWater(0))} className="shrink-0 px-3">
                    <RotateCcw size={16} />
                  </Button>
                </div>
                <div className="mt-4 grid grid-cols-3 gap-2">
                  {[250, 500, 750].map((amount) => (
                    <button key={amount} type="button" onClick={() => handleAddWater(amount)} className="ff-quick-water-button">
                      +{amount}ml
                    </button>
                  ))}
                </div>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  <button type="button" onClick={() => handleAddWater(-250)} className="ff-quick-water-button ff-quick-water-button-muted">-250ml</button>
                  <button type="button" onClick={() => handleAddWater(-500)} className="ff-quick-water-button ff-quick-water-button-muted">-500ml</button>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-4 sm:p-5">
            <div className="mb-4 flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[var(--ff-accent-soft)] text-[var(--ff-accent-text)]">
                <Utensils size={21} />
              </span>
              <div>
                <h2 className="text-xl font-black">Nova refeição</h2>
                <p className="text-sm text-[var(--ff-muted)]">Registre alimento, macros e uma foto opcional.</p>
              </div>
            </div>

            <form onSubmit={handleAddMeal} className="space-y-4">
              <div className="grid grid-cols-1 gap-3 md:grid-cols-[minmax(0,1.2fr)_210px_130px]">
                <Input label="Nome" value={meal.name} onChange={(event) => setMeal((current) => ({ ...current, name: event.target.value }))} placeholder="Almoço, omelete, shake..." />
                <Select label="Tipo" value={meal.type} onChange={(event) => setMeal((current) => ({ ...current, type: event.target.value }))}>
                  {MEAL_TYPES.map((type) => <option key={type.value} value={type.value}>{type.label}</option>)}
                </Select>
                <Input label="Hora" type="time" value={meal.time} onChange={(event) => setMeal((current) => ({ ...current, time: event.target.value }))} />
              </div>

              <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                <Input label="Kcal" type="number" min="0" inputMode="numeric" value={meal.calories} onChange={(event) => setMeal((current) => ({ ...current, calories: event.target.value }))} />
                <Input label="Proteína" type="number" min="0" inputMode="decimal" value={meal.proteinG} onChange={(event) => setMeal((current) => ({ ...current, proteinG: event.target.value }))} />
                <Input label="Carbo" type="number" min="0" inputMode="decimal" value={meal.carbsG} onChange={(event) => setMeal((current) => ({ ...current, carbsG: event.target.value }))} />
                <Input label="Gordura" type="number" min="0" inputMode="decimal" value={meal.fatG} onChange={(event) => setMeal((current) => ({ ...current, fatG: event.target.value }))} />
              </div>

              <MealPhotoPicker photo={meal.photo} onChange={(photo) => setMeal((current) => ({ ...current, photo }))} error={photoError} onError={setPhotoError} />
              <Textarea label="Observação" rows={3} value={meal.notes} onChange={(event) => setMeal((current) => ({ ...current, notes: event.target.value }))} placeholder="Opcional: fome, horário, pré-treino, onde comeu..." />

              <Button type="submit" className="w-full">
                <Plus size={16} /> Salvar refeição
              </Button>
            </form>
          </Card>

          <Card className="p-4 sm:p-5">
            <div className="mb-4 flex items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-black">Refeições de hoje</h2>
                <p className="text-sm text-[var(--ff-muted)]">Fotos e macros do dia em ordem recente.</p>
              </div>
              <Camera size={22} className="text-[var(--ff-accent-text)]" />
            </div>

            <div className="space-y-3">
              {nutrition.meals?.length ? nutrition.meals.map((item) => (
                <div key={item.id} className="ff-meal-list-item">
                  {item.photo?.dataUrl ? (
                    <img src={item.photo.dataUrl} alt={item.name} className="h-20 w-20 shrink-0 rounded-2xl object-cover" />
                  ) : (
                    <span className="flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl bg-[var(--ff-surface-3)] text-[var(--ff-muted)]"><Utensils size={24} /></span>
                  )}
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="truncate text-sm font-black text-[var(--ff-text)]">{item.name}</p>
                      <Badge>{getMealTypeLabel(item.type)}</Badge>
                    </div>
                    <p className="mt-1 text-xs text-[var(--ff-muted)]">{item.time} · {item.calories} kcal · {item.proteinG}g prot. · {item.carbsG || 0}g carb. · {item.fatG || 0}g gord.</p>
                    {item.notes && <p className="mt-1 line-clamp-2 text-xs text-[var(--ff-text-soft)]">{item.notes}</p>}
                  </div>
                  <Button variant="ghost" onClick={() => setNutrition(removeMeal(item.id))} className="shrink-0 px-3">
                    <Trash2 size={16} />
                  </Button>
                </div>
              )) : (
                <div className="rounded-3xl border border-dashed border-[var(--ff-border)] p-6 text-center">
                  <Utensils size={28} className="mx-auto text-[var(--ff-muted)]" />
                  <p className="mt-3 text-sm font-bold text-[var(--ff-text)]">Nenhuma refeição registrada hoje</p>
                  <p className="mt-1 text-xs text-[var(--ff-muted)]">Adicione uma refeição para acompanhar calorias, proteína e fotos.</p>
                </div>
              )}
            </div>
          </Card>
        </div>

        <Card className="p-4 sm:p-5">
          <p className="text-xs font-black uppercase tracking-[0.16em] text-[var(--ff-accent-text)]">Metas do dia</p>
          <h2 className="mt-1 text-xl font-black">Ajuste rápido</h2>
          <p className="mt-1 text-sm text-[var(--ff-muted)]">As metas ficam salvas localmente neste dispositivo nesta primeira versão.</p>

          <form onSubmit={handleSaveGoals} className="mt-4 space-y-3">
            <Input label="Meta de água (ml)" type="number" min="500" inputMode="numeric" value={goals.waterGoalMl} onChange={(event) => setGoals((current) => ({ ...current, waterGoalMl: event.target.value }))} />
            <Input label="Meta de calorias" type="number" min="500" inputMode="numeric" value={goals.calorieGoal} onChange={(event) => setGoals((current) => ({ ...current, calorieGoal: event.target.value }))} />
            <Input label="Meta de proteína (g)" type="number" min="20" inputMode="numeric" value={goals.proteinGoalG} onChange={(event) => setGoals((current) => ({ ...current, proteinGoalG: event.target.value }))} />
            <Button type="submit" className="w-full">Salvar metas</Button>
          </form>

          <div className="mt-5 rounded-3xl border border-[var(--ff-border)] bg-[var(--ff-surface-2)] p-4">
            <h3 className="font-black">Base para próxima etapa</h3>
            <p className="mt-2 text-sm leading-relaxed text-[var(--ff-muted)]">A estrutura já suporta refeição com foto, macros e metas. Depois pode evoluir para backend, histórico semanal e objetivos nutricionais.</p>
          </div>
        </Card>
      </section>
    </div>
  
    </div>
  )
}

export default Nutrition

import { Link } from 'react-router-dom'
import {
  Dumbbell,
  Flame,
  HeartPulse,
  Search,
  ShieldCheck,
  X,
} from 'lucide-react'

import PageHeader from '../../../components/ui/PageHeader'
import Card from '../../../components/ui/Card'
import Badge from '../../../components/ui/Badge'
import EmptyState from '../../../components/ui/EmptyState'
import Button from '../../../components/ui/Button'
import {
  formatDate,
  formatRelativeDate,
  formatVolume,
  getRecoveryStyle,
} from '../muscleRecoveryUtils'

const STATUS_OPTIONS = [
  { value: '', label: 'Todos' },
  { value: 'low', label: 'Recuperando' },
  { value: 'medium', label: 'Parcial' },
  { value: 'good', label: 'Quase pronto' },
  { value: 'ready', label: 'Recuperado' },
]

function RecoveryHeader({ source, loading }) {
  return (
    <PageHeader
      title="Recuperação muscular"
      description="Acompanhe quais grupos musculares foram treinados recentemente e quais já estão mais recuperados."
      action={
        <Badge variant={source === 'database' ? 'purple' : 'default'}>
          {loading ? 'Carregando...' : source === 'database' ? 'Sincronizado' : 'Local'}
        </Badge>
      }
    />
  )
}

function RecoveryStats({ recovery, averageRecovery, readyMuscles, recoveringMuscles }) {
  const cards = [
    {
      label: 'Grupos analisados',
      value: recovery.length,
      description: 'com histórico recente',
      icon: Dumbbell,
      valueClass: '',
      iconClass: 'text-[var(--ff-accent-text)]',
    },
    {
      label: 'Recuperação média',
      value: `${averageRecovery}%`,
      description: 'estimativa geral',
      icon: HeartPulse,
      valueClass: 'text-[var(--ff-accent-text)]',
      iconClass: 'text-[var(--ff-accent-text)]',
    },
    {
      label: 'Prontos',
      value: readyMuscles.length,
      description: 'grupos recuperados',
      icon: ShieldCheck,
      valueClass: 'text-emerald-300',
      iconClass: 'text-emerald-400',
    },
    {
      label: 'Atenção',
      value: recoveringMuscles.length,
      description: 'ainda recuperando',
      icon: Flame,
      valueClass: 'text-yellow-300',
      iconClass: 'text-yellow-400',
    },
  ]

  return (
    <section className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {cards.map((card) => {
        const Icon = card.icon

        return (
          <Card key={card.label} className="p-4">
            <div className="flex items-center justify-between">
              <p className="text-sm text-zinc-500">{card.label}</p>
              <Icon size={20} className={card.iconClass} />
            </div>
            <h2 className={`mt-2 text-3xl font-black ${card.valueClass}`}>{card.value}</h2>
            <p className="mt-2 text-xs text-zinc-500">{card.description}</p>
          </Card>
        )
      })}
    </section>
  )
}

function MobileRecoveryFilters({ statusFilter, onStatusFilterChange }) {
  return (
    <section className="mt-5 xl:hidden">
      <div className="-mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
        {STATUS_OPTIONS.map((option) => (
          <button
            key={option.value || 'all'}
            type="button"
            onClick={() => onStatusFilterChange(option.value)}
            className={
              statusFilter === option.value
                ? 'shrink-0 rounded-full border border-[var(--ff-accent-border)] bg-[var(--ff-accent-soft)] px-4 py-2 text-xs font-black text-[var(--ff-accent-text)]'
                : 'shrink-0 rounded-full border border-zinc-800 bg-zinc-950 px-4 py-2 text-xs font-bold text-zinc-400'
            }
          >
            {option.label}
          </button>
        ))}
      </div>
    </section>
  )
}

function RecoveryFiltersCard({ search, statusFilter, onSearchChange, onStatusFilterChange, onClearFilters }) {
  return (
    <Card>
      <div className="flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[var(--ff-accent-soft)]/10 text-[var(--ff-accent-text)]">
          <Search size={22} />
        </div>

        <div>
          <h2 className="text-lg font-black">Filtros</h2>
          <p className="text-sm text-zinc-500">Refine por grupo ou status.</p>
        </div>
      </div>

      <div className="mt-5 space-y-3">
        <div className="flex h-12 items-center gap-3 rounded-2xl border border-zinc-800 bg-[#101014] px-4 text-zinc-400">
          <Search size={19} />
          <input
            type="search"
            placeholder="Buscar grupo..."
            value={search}
            onChange={(event) => onSearchChange(event.target.value)}
            className="w-full bg-transparent text-sm text-white outline-none placeholder:text-zinc-500"
          />

          {search && (
            <button type="button" onClick={() => onSearchChange('')} className="text-zinc-500 transition hover:text-white">
              <X size={17} />
            </button>
          )}
        </div>

        <select
          value={statusFilter}
          onChange={(event) => onStatusFilterChange(event.target.value)}
          className="h-12 w-full rounded-2xl border border-zinc-800 bg-[#101014] px-4 text-sm font-bold text-white outline-none transition hover:border-zinc-700 focus:border-[var(--ff-accent-border)]"
        >
          <option value="">Todos os status</option>
          <option value="low">Recuperando</option>
          <option value="medium">Parcial</option>
          <option value="good">Quase pronto</option>
          <option value="ready">Recuperado</option>
        </select>

        {(search || statusFilter) && (
          <Button type="button" variant="secondary" onClick={onClearFilters} className="w-full">
            Limpar filtros
          </Button>
        )}
      </div>
    </Card>
  )
}

function SuggestedMusclesCard({ nextSuggestedMuscles }) {
  return (
    <Card>
      <h2 className="text-lg font-black">Sugestão para hoje</h2>
      <p className="mt-1 text-sm text-zinc-500">Grupos com maior recuperação.</p>

      <div className="mt-5 space-y-2">
        {nextSuggestedMuscles.length === 0 ? (
          <p className="text-sm text-zinc-500">Ainda não há dados suficientes para sugerir.</p>
        ) : (
          nextSuggestedMuscles.map((item) => {
            const style = getRecoveryStyle(item.level)

            return (
              <div key={item.muscleGroup} className={`rounded-2xl border ${style.border} ${style.bg} p-3`}>
                <div className="flex items-center justify-between gap-3">
                  <p className="font-bold text-white">{item.muscleGroup}</p>
                  <span className={`text-sm font-black ${style.text}`}>{item.recoveryPercent}%</span>
                </div>
                <p className="mt-1 text-xs text-zinc-500">{item.status}</p>
              </div>
            )
          })
        )}
      </div>

      <Link to="/workouts">
        <button
          type="button"
          className="mt-5 flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-[var(--ff-accent)] text-sm font-bold text-white transition hover:bg-[var(--ff-accent-hover)]"
        >
          <Dumbbell size={18} />
          Montar treino
        </button>
      </Link>
    </Card>
  )
}

function RecoveryInfoCard() {
  return (
    <Card>
      <h2 className="text-lg font-black">Como funciona?</h2>
      <p className="mt-3 text-sm leading-relaxed text-zinc-500">
        A recuperação é estimada pelo tempo desde o último treino de cada grupo muscular.
        O cálculo foi ajustado para considerar a virada do dia: mudou o dia, já conta como +1 dia de recuperação.
      </p>

      <div className="mt-4 space-y-2 text-sm">
        <div className="rounded-2xl border border-red-500/20 bg-red-500/10 p-3 text-red-200">Mesmo dia: recuperando</div>
        <div className="rounded-2xl border border-yellow-500/20 bg-yellow-500/10 p-3 text-yellow-200">Dia seguinte: parcial</div>
        <div className="rounded-2xl border border-blue-500/20 bg-blue-500/10 p-3 text-blue-200">2 dias depois: quase pronto</div>
        <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-3 text-emerald-200">3 dias ou mais: recuperado</div>
      </div>
    </Card>
  )
}

function MuscleRecoveryCard({ item }) {
  const style = getRecoveryStyle(item.level)
  const Icon = style.icon

  return (
    <div className={`rounded-3xl border ${style.border} ${style.bg} p-5`}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl ${style.bg} ${style.text}`}>
            <Icon size={22} />
          </div>
          <div>
            <h3 className="text-xl font-black text-white">{item.muscleGroup}</h3>
            <p className={`mt-1 text-sm font-bold ${style.text}`}>{item.status}</p>
          </div>
        </div>

        <span className={`text-2xl font-black ${style.text}`}>{item.recoveryPercent}%</span>
      </div>

      <div className="mt-5 h-3 overflow-hidden rounded-full bg-black/30">
        <div className={`h-full rounded-full ${style.bar}`} style={{ width: `${item.recoveryPercent}%` }} />
      </div>

      <p className="mt-4 text-sm leading-relaxed text-zinc-400">{item.message}</p>

      <div className="mt-5 grid grid-cols-2 gap-3">
        <div className="rounded-2xl border border-black/20 bg-black/20 p-4">
          <p className="text-xs text-zinc-500">Último treino</p>
          <p className="mt-1 text-sm font-bold text-white">{formatRelativeDate(item.lastTrainedAt)}</p>
          <p className="mt-1 text-xs text-zinc-500">{formatDate(item.lastTrainedAt)}</p>
        </div>
        <div className="rounded-2xl border border-black/20 bg-black/20 p-4">
          <p className="text-xs text-zinc-500">Séries recentes</p>
          <p className="mt-1 text-lg font-black text-white">{item.totalSets}</p>
        </div>
        <div className="rounded-2xl border border-black/20 bg-black/20 p-4">
          <p className="text-xs text-zinc-500">Sessões</p>
          <p className="mt-1 text-lg font-black text-white">{item.totalSessions}</p>
        </div>
        <div className="rounded-2xl border border-black/20 bg-black/20 p-4">
          <p className="text-xs text-zinc-500">Volume</p>
          <p className="mt-1 text-sm font-black text-[var(--ff-accent-text)]">{formatVolume(item.totalVolume)}</p>
        </div>
      </div>
    </div>
  )
}

function RecoveryGrid({ filteredRecovery }) {
  return (
    <main>
      <Card>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <h2 className="text-2xl font-black">Grupos musculares</h2>
            <p className="mt-1 text-sm text-zinc-500">{filteredRecovery.length} grupo(s) encontrados.</p>
          </div>
          <Badge>Recuperação</Badge>
        </div>

        <div className="mt-5">
          {filteredRecovery.length === 0 ? (
            <EmptyState
              title="Nenhum grupo encontrado"
              description="Finalize alguns treinos ou ajuste os filtros para ver a recuperação muscular."
            />
          ) : (
            <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
              {filteredRecovery.map((item) => (
                <MuscleRecoveryCard key={item.muscleGroup} item={item} />
              ))}
            </div>
          )}
        </div>
      </Card>
    </main>
  )
}

export default function MuscleRecoveryPageSections({
  source,
  loading,
  recovery,
  averageRecovery,
  readyMuscles,
  recoveringMuscles,
  nextSuggestedMuscles,
  filteredRecovery,
  search,
  statusFilter,
  onSearchChange,
  onStatusFilterChange,
  onClearFilters,
}) {
  return (
    <>
      <RecoveryHeader source={source} loading={loading} />
      <RecoveryStats
        recovery={recovery}
        averageRecovery={averageRecovery}
        readyMuscles={readyMuscles}
        recoveringMuscles={recoveringMuscles}
      />
      <MobileRecoveryFilters statusFilter={statusFilter} onStatusFilterChange={onStatusFilterChange} />

      <section className="mt-6 grid grid-cols-1 gap-4 sm:gap-6 xl:grid-cols-[330px_minmax(0,1fr)]">
        <aside className="space-y-6">
          <RecoveryFiltersCard
            search={search}
            statusFilter={statusFilter}
            onSearchChange={onSearchChange}
            onStatusFilterChange={onStatusFilterChange}
            onClearFilters={onClearFilters}
          />
          <SuggestedMusclesCard nextSuggestedMuscles={nextSuggestedMuscles} />
          <RecoveryInfoCard />
        </aside>
        <RecoveryGrid filteredRecovery={filteredRecovery} />
      </section>
    </>
  )
}
